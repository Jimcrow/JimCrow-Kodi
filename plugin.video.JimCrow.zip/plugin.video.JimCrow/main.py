# -*- coding: utf-8 -*-
"""
#------------------------------------------------------------
# Jim Crow
# Copyright 2017
# TEST 5/9/2017 11:33
#------------------------------------------------------------
"""

import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
# import downloader
# import login

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'sports', 'foldername': 'sports'})
    li = xbmcgui.ListItem('Sports', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/sports.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'kids', 'foldername': 'kids'})
    li = xbmcgui.ListItem('Kids', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/kids.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'iptv', 'foldername': 'iptv'})
    li = xbmcgui.ListItem('IPTV', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/iptv.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'documentary', 'foldername': 'documentary'})
    li = xbmcgui.ListItem('Documentary', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/documentary.png')	
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'movies', 'foldername': 'movies'})
    li = xbmcgui.ListItem('Movies', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/movies.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'series', 'foldername': 'series'})
    li = xbmcgui.ListItem('TV Series', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/series.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'Shows', 'foldername': 'Shows'})
    li = xbmcgui.ListItem('Shows', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/Shows.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)	

    url = build_url({'mode': 'music', 'foldername': 'music'})
    li = xbmcgui.ListItem('Music', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/music.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'XXX videos', 'foldername': 'XXX videos'})
    li = xbmcgui.ListItem('XXX Videos', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/XXX.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)								
								
    xbmcplugin.endOfDirectory(addon_handle)
#--------------------------------------------------------------------------------------------SPORTS--------------------------------------------------------------------------------------------
elif mode[0] == 'sports':
    foldername = args['foldername'][0]
#-----------------------Special Event------------------------------	
    url = 'https://www.dropbox.com/s/3jtiwrlrka1wr5u/Special%20Event%201.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Special Event 1[COLOR red]#####[/COLOR]', iconImage='https://gafirst.org/wp-content/uploads/2016/12/special_event.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)	
    url = 'https://www.dropbox.com/s/r5eu8psvoxljtg3/Special%20Event%202.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Special Event 2[COLOR red]#####[/COLOR]', iconImage='https://gafirst.org/wp-content/uploads/2016/12/special_event.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#-----------------------BackupSportList------------------------------	
    url = 'https://www.dropbox.com/s/ctuknfn6e56hxre/SportsBackup.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Backup Sport List[COLOR red]#####[/COLOR]', iconImage='https://gafirst.org/wp-content/uploads/2016/12/special_event.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#--------------------------Nova Sport-----------------------------	
 #   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7071.ts'
 #  li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nova Sport 1 HD GR[COLOR red]#####[/COLOR]', iconImage='http://www.nova.gr/files/1/HD_changes_Aug16/Logos/novasports-theama/ns1HD.jpg')
 #   xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 #   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5880.ts'
 #   li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nova Sport 1 HD Backup[COLOR red]#####[/COLOR]', iconImage='http://www.nova.gr/files/1/HD_changes_Aug16/Logos/novasports-theama/ns1HD.jpg')
 #   xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
 #   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7070.ts'
 #   li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nova Sport 2 HD GR[COLOR red]#####[/COLOR]', iconImage='http://www.nova.gr/files/1/HD_changes_Aug16/Logos/novasports-theama/ns2HD.jpg')
 #   xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#--------------------------OTE Sport-----------------------------	
#OTE Sport 1 HD
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2806.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 1 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528672&t=1479076521567')
#OTE Sport 1 
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2858.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 1 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/OTETV-theme/images/noimage-landscape.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 2 HD
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2807.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 2 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528871&t=1479076532369')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 2
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2859.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 2[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/OTETV-theme/images/noimage-landscape.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 3 HD 
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2808.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 3 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528775&t=1479076526495')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2860.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 3 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528775&t=1479076526495')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 4 HD 	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2809.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 4 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528893&t=1479076533576')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2861.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 4 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528893&t=1479076533576')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 5 HD 
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2810.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 5 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528905&t=1479076534248')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 6 HD 
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2811.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 6 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528787&t=1479076527140')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 7 HD 
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2812.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 7 HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528839&t=1479076530484')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#OTE Sport 8 HD 
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2813.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Sport 8 HD GR [COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528819&t=1479076529116')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#--------------------------EuroSport-----------------------------	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2212.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]EuroSport 1 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236418&t=1495247859526')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2223.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]EuroSport 1[COLOR red]#####[/COLOR]', iconImage='http://streaming24.live/wp-content/uploads/2017/02/Eurosport-1.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#-----------------------UK BT SPORT------------------------------	
#1
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5716.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT 1 HD[COLOR red]#####[/COLOR]', iconImage='https://ia801500.us.archive.org/16/items/BtSport1/bt%20sport%201.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#2	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5715.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT 2 HD[COLOR red]#####[/COLOR]', iconImage='https://ia801506.us.archive.org/23/items/BtSport2_201708/bt%20sport%202.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#3	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5714.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT 3 HD[COLOR red]#####[/COLOR]', iconImage='https://ia601504.us.archive.org/13/items/BtSport3Hd/bt%20sport%203%20hd.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#ESPN	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1743.ts	'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT ESPN HD[COLOR red]#####[/COLOR]', iconImage='https://ia601505.us.archive.org/33/items/BtSportEspnHd/bt%20sport%20espn%20hd.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#Extra	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1818.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT EXTRA 1 SD[COLOR red]#####[/COLOR]', iconImage='https://ia801501.us.archive.org/34/items/BtSportExtra1/bt%20sport%20extra%201.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#Extra2
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1817.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT EXTRA 2 SD[COLOR red]#####[/COLOR]', iconImage='https://ia801504.us.archive.org/23/items/BtSportExtra2/bt%20sport%20extra%202%20.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#Extra3
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1816.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT EXTRA 3 SD[COLOR red]#####[/COLOR]', iconImage='https://ia601507.us.archive.org/24/items/BtSportExtra3/bt%20sport%20extra%203%20.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#Extra4
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1815.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT EXTRA 4[COLOR red]#####[/COLOR]', iconImage='https://ia801507.us.archive.org/3/items/BtSportExtra4/bt%20sport%20extra%204.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#Extra5	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/1814.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]UK BT SPORT EXTRA 5[COLOR red]#####[/COLOR]', iconImage='https://ia801503.us.archive.org/16/items/BtSportExtra5/bt%20sport%20extra%205.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)
#--------------------------------------------------------------------------------------------KIDS--------------------------------------------------------------------------------------------
elif mode[0] == 'kids':
    foldername = args['foldername'][0]
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PL3E1C926284F12F32'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Mythology list[COLOR red]#####[/COLOR]', iconImage='https://i.pinimg.com/736x/7b/38/8e/7b388efaec618489be95c1625c7543dc--roman-mythology-greek-mythology.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
# -------------Channels ----------- GR	-----
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5850.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Baby TV GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=10520172&t=1475832506512')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2200.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Smile TV GR [COLOR red]#####[/COLOR]', iconImage='https://scontent.fath1-1.fna.fbcdn.net/v/t1.0-9/14291786_1440598855955410_8230064026082769192_n.png?oh=6daaf4d0badb0ea3fe0a8cfa2f5b3d6d&oe=5A299BC0')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5853.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Disney Channel GR[COLOR red]#####[/COLOR]', iconImage='https://upload.wikimedia.org/wikipedia/fr/thumb/a/a7/Logo_DisneyChannel2002.png/120px-Logo_DisneyChannel2002.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5852.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Disney Junior GR[COLOR red]#####[/COLOR]', iconImage='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTS6TyKESe1C_RAgZqfq__-H1oJ4bzvw_RLk5Y-0FquiSddKaFo')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5851.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Disney XD GR[COLOR red]#####[/COLOR]', iconImage='https://r.dcs.redcdn.pl/file/o2/redefine/redb/bq/bqyfid94od6nusy3y1x2pft5y1qerfcd.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2196.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nickelodeon[COLOR red]#####[/COLOR]', iconImage='https://www.thelogodb.com/images/media/logo/turwts1438374001.png/preview')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
# --------Kids Channels	------------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5849.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 1 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5848.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 2 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5847.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 3 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5846.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 4 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5845.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 5 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5844.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 6 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5843.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 7 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5841.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 8 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5840.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kids TV 9 GR[COLOR red]#####[/COLOR]', iconImage='https://lh3.googleusercontent.com/yOsjb_TyqNf8nSOE3A1XkZc6_29J0zsT52haWn6xW70FCFfVpxPQ0q-fXTd-2y10Lkc=w300')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#--------------------------	
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    xbmcplugin.endOfDirectory(addon_handle)
#--------------------------------------------------------------------------------------------IPTV--------------------------------------------------------------------------------------------	
elif mode[0] == 'iptv':
    foldername = args['foldername'][0]
    url = 'https://www.dropbox.com/s/j2mdjrfxh6m3u8s/AllGR.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]All GR IPTV Channels[COLOR red]#####[/COLOR]', iconImage='http://s1.media.ricoh-imaging.gr/media/23d2bd0f6e67535f4838a2cc48580822/gr-product-logo.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'https://www.dropbox.com/s/9ukjl9g59v9kdk6/World.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]All World GR IPTV Channels[COLOR red]#####[/COLOR]', iconImage='http://www.freeiconspng.com/uploads/colorful-world-icon-33.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
# ERT --------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2215.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 1 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242571&t=1473885924793')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/871.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 1 GR Backup[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242571&t=1473885924793')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2214.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 2 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242967&t=1473887075807')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/866.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 2 GR Backup[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242967&t=1473887075807')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2213.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 3 GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242655&t=1473886025317')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/865.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT 3 GR Backup[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242655&t=1473886025317')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/872.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]ERT HD GR [COLOR red]#####[/COLOR]', iconImage='')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
# ------------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2219.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Alpha GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/47603-alphatv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/855.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Alpha GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/47603-alphatv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2239.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Antena 1 GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/c788d-ant1_tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/856.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Antena 1 GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/c788d-ant1_tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2235.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Mega GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/b27db-mega.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/862.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Mega GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/b27db-mega.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2201.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Skai GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/02e79-skai_tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/850.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Skai GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/02e79-skai_tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2199.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Star GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/68f2a-starchannellivetv.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/848.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Star GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/68f2a-starchannellivetv.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5825.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]E[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/bd11e-25ce259525ce25a825ce259925ce259b25ce259f25ce259dtv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/869.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]E Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/bd11e-25ce259525ce25a825ce259925ce259b25ce259f25ce259dtv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2208.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Makedonia[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/9d5db-ce9cce91ce9ace95ce94ce9fce9dce99ce91tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/854.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Makedonia Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/9d5db-ce9cce91ce9ace95ce94ce9fce9dce99ce91tv.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)	
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5839.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]MAD[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/4a6fb-madtvchannellivestreaminggreektv.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/857.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]MAD Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/4a6fb-madtvchannellivestreaminggreektv.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5820.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]RIK 1 Cyprus GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/a90d7-ricsat.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5819.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]RIK 2 Cyprus GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/a90d7-ricsat.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2863.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]RIK Sat GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/a90d7-ricsat.jpg?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2209.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kriti TV GR[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/7b7ed-ce9acea1ce97cea4ce97tvlive.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2850.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Kriti TV GR Backup[COLOR red]#####[/COLOR]', iconImage='https://elatora.files.wordpress.com/2014/05/7b7ed-ce9acea1ce97cea4ce97tvlive.png?w=126&h=90')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
# ------------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5863.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE History GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528975&t=1479076537395')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5881.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]NovaCinema 1 HD GR[COLOR red]#####[/COLOR]', iconImage='http://www.nova.gr/files/1/NovaChannels/novagoHD/nc1hd.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://iptviptv.it:25461/live/donafabby1/b3Dd1hJ5wX/25002.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]E! Ent[COLOR red]#####[/COLOR]', iconImage='https://lh4.googleusercontent.com/-50uObYxJUrs/AAAAAAAAAAI/AAAAAAACi7M/1N0pWkHuRU4/s0-c-k-no-ns/photo.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2237.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Animal Planet GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236574&t=1495247920782')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5862.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Animal Planet HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236574&t=1495247920782')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2232.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery Channel GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242727&t=1473886519683')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://ipsatpro.com:8000/live/190001659542687/190001659542687/2826.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery Channel GR Backup[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=9242727&t=1473886519683')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5859.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery ID GR[COLOR red]#####[/COLOR]', iconImage='http://www.tigostar.cr/sites/tigostar.cr/files/channels/logo-id.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5860.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery IDX GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236598&t=1495247930732')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5857.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery Science GR[COLOR red]#####[/COLOR]', iconImage='http://content.osn.com/logo/channel/cropped/SCI.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2197.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Discovery ShowCase HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236538&t=1495247907247')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5858.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]DTX GR[COLOR red]#####[/COLOR]', iconImage='https://upload.wikimedia.org/wikipedia/en/5/51/DTX_Discovery_logo.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5854.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Fishing Ellinika GR[COLOR red]#####[/COLOR]', iconImage='https://www.niwa.co.nz/sites/niwa.co.nz/files/styles/thumbnail/public/icons/icon-fisheries_0.png?itok=ke0YQb96')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2233.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]History HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.jetblue.com/img/fojb/directv/logos/direct_tv_history.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5855.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hunting Ellinika GR[COLOR red]#####[/COLOR]', iconImage='https://s-media-cache-ak0.pinimg.com/736x/1c/f7/a6/1cf7a6d0a0208c3b9c6de4fc42893fe4--pheasant-hunting-duck-hunting.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2236.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nat Geo HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236526&t=1495247902976')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2234.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nat Geo Wild HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236562&t=1495247916143')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5880.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Sundance HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236466&t=1495247878727')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2211.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Travel Channel HD GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236586&t=1495247925721')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5861.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Viasat History GR[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22829244&t=1496137198832')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)	
#--------------------------------------------------------------------------------------------DOCUMENTARY--------------------------------------------------------------------------------------------	
elif mode[0] == 'documentary':
    foldername = args['foldername'][0]
    url = 'https://www.dropbox.com/s/3h6d82q85enzzrh/documentary.m3u?dl=1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]GR Documentary[COLOR red]#####[/COLOR]', iconImage='https://www.dropbox.com/s/gq120uwj0mw4mrl/documentary.png?dl=1')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)
#--------------------------------------------------------------------------------------------MOVIES--------------------------------------------------------------------------------------------
elif mode[0] == 'movies':
    foldername = args['foldername'][0]
    url = 'https://raw.githubusercontent.com/fluxustv/IPTV/master/cinema.m3u'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies List[COLOR red]#####[/COLOR]', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/movies.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5873.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Cinema 1 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5872.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Cinema 1 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5879.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 1 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5878.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 2 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5877.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 3 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5876.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 4 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5875.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 5 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5874.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Movies GR Subs 6 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#------------------------OTE Cinema -------------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7081.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Cinema 1 HD [COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528694&t=1479076522659')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7082.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Cinema 2 HD [COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528851&t=1479076531116')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7077.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Cinema 3 HD [COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22829232&t=1496137192596')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7076.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]OTE Cinema 4 HD [COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=12528807&t=1479076528519')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
#------------------------NovaCinema-------------
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5881.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]NovaCinema 1 HD GR[COLOR red]#####[/COLOR]', iconImage='http://www.novaguide.gr/files/1/Channels/LOGOS90X85/01_cinema/NC1HD-90x85.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7080.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]NovaCinema 2 HD[COLOR red]#####[/COLOR]', iconImage='http://www.novaguide.gr/files/1/Channels/LOGOS90X85/01_cinema/NC2HD-90x85.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7079.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]NovaCinema 3 HD[COLOR red]#####[/COLOR]', iconImage='http://www.novaguide.gr/files/1/Channels/LOGOS90X85/01_cinema/NC3HD-90x85.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/7078.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]NovaCinema 4 HD[COLOR red]#####[/COLOR]', iconImage='http://www.novaguide.gr/files/1/Channels/LOGOS90X85/01_cinema/NC4HD-90x85.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)				
#--------------------------------------------------------------------------------------------SERIES--------------------------------------------------------------------------------------------	
elif mode[0] == 'series':
    foldername = args['foldername'][0]
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5865.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Greek Series 1 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5864.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Greek Series 2 24/7[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PL-ta1B48ye1kerLFrHMRfMaTLqDuepJkf'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]TO SOI SOY[COLOR red]#####[/COLOR]', iconImage='https://upload.wikimedia.org/wikipedia/el/thumb/3/30/%CE%A4%CE%BF-%CF%83%CF%8C%CE%B9-%CF%83%CE%BF%CF%85-1..jpg/325px-%CE%A4%CE%BF-%CF%83%CF%8C%CE%B9-%CF%83%CE%BF%CF%85-1..jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PLrZImhph4ZsFPc6Ze6cAFdLcdePPbufQI'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]STO PARA PENTE[COLOR red]#####[/COLOR]', iconImage='https://upload.wikimedia.org/wikipedia/el/f/f5/Sto_Para_Pente_logo.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PLrZImhph4ZsH5YWMj2vKkh423bd1xf-B1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]MHN ARXIZEIS THN MOYRMOYRA[COLOR red]#####[/COLOR]', iconImage='http://www.alphatv.gr/sites/tv/files/styles/large/public/logo_min_arhizeis_ti_moyrmoyra_1.jpg?itok=oZcGLi-7')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PL77596E877D952D48'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]KONSTANTINOY KAI ELENHS[COLOR red]#####[/COLOR]', iconImage='http://2.bp.blogspot.com/-hS88fBHn4U8/Umawc9tWN7I/AAAAAAAARmY/CGEvI_DDun0/s320/%CE%BA%CF%89%CE%BD%CE%BA%CE%B5%CE%BB.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PL8Pra97AUsbuJd3hOXAtIokESlc_TxZm1'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Ths Ellados ta paidia[COLOR red]#####[/COLOR]', iconImage='http://www.youweekly.gr/wp-content/uploads/2016/04/paidia.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)							
#--------------------------------------------------------------------------------------------SHOWS--------------------------------------------------------------------------------------------	
elif mode[0] == 'Shows':
    foldername = args['foldername'][0]
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PLCg0cLoEdHTyv8AmyrN7ARcXUTKqUG57E'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Shopping Star[COLOR red]#####[/COLOR]', iconImage='http://www.star.gr/tv/PublishingImages/2016/11/101116184732_2626.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PLfR52XtXQls1NYW1ImpgfQqefCtf9CTAg'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]The 2Night Show[COLOR red]#####[/COLOR]', iconImage='http://www.peoplegreece.com/wp-content/uploads/2015/11/01/the-2night-show.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)								
#--------------------------------------------------------------------------------------------MUSIC--------------------------------------------------------------------------------------------
elif mode[0] == 'music':
    foldername = args['foldername'][0]
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=PLLtBDrsiIaQvOVq0j1jUkUkIaN4fn3aCm'
    li = xbmcgui.ListItem('[COLOR green]---[/COLOR]Load Playlist Rock anthems By Nikos[COLOR green]---[/COLOR]', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/music.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.youtube/?path=/root/video&action=play_all&playlist=RD3lTAwk5VXq4'
    li = xbmcgui.ListItem('[COLOR green]---[/COLOR]Load Playlist Greek Rock[COLOR green]---[/COLOR]', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/music.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5839.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]MAD TV[COLOR red]#####[/COLOR]', iconImage='')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/5814.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]MAD TV Cyprus[COLOR red]#####[/COLOR]', iconImage='special://home/addons/plugin.video.JimCrow/resources/img/music.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)
#--------------------------------------------------------------------------------------------XXX VIDEOS--------------------------------------------------------------------------------------------	
elif mode[0] == 'XXX videos':
    foldername = args['foldername'][0]
    url = 'https://raw.githubusercontent.com/fluxustv/IPTV/master/xxx.m3u'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXX Channel list 1[COLOR red]#####[/COLOR]', iconImage='https://2.bp.blogspot.com/-tW3kUrnyW18/WZ5nWLgXmTI/AAAAAAAAA6o/3HbhMetwyXM-OmDhuqPda4r6rrF_7zk1QCLcBGAs/s320/FluxuLustList.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'http://exabytetv.info/xvid.m3u'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXX Channel list 2[COLOR red]#####[/COLOR]', iconImage='https://2.bp.blogspot.com/-tW3kUrnyW18/WZ5nWLgXmTI/AAAAAAAAA6o/3HbhMetwyXM-OmDhuqPda4r6rrF_7zk1QCLcBGAs/s320/FluxuLustList.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2243.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Sirina 1 Adult[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236658&t=1495247952734')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2242.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Sirina 2 Adult[COLOR red]#####[/COLOR]', iconImage='https://www.cosmote.gr/portal/image/journal/article?img_id=22236658&t=1495247952734')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2276.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Beate-Uhse TV (20-06) Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2242.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]BRAZZERS TV Europe Adult[COLOR red]#####[/COLOR]', iconImage='2275')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2274.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hot Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2242.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]CentoXCento Adult[COLOR red]#####[/COLOR]', iconImage='2273')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2242.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Desire Adult[COLOR red]#####[/COLOR]', iconImage='2272')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2271.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Dorcel TV HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2270.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]DUSK! DeLuxe Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2269.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Eroxx HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2268.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Evil Angel TV Adult[COLOR red]#####[/COLOR]', iconImage='2268')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2267.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]FreeX TV Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2266.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hot Club 1 HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2265.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hot Club 2 HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2264.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hot Club 3 HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2263.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Hustler HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2262.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Jasmin.tv Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2260.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Soft Sex Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2259.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Nubiles Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2247.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Reality Kings TV Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2246.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]RedLight HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]PassieXXX Adult[COLOR red]#####[/COLOR]', iconImage='http://portal.geniptv.com:8080/live/deric/deric/2258.ts')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url=http://portal.geniptv.com:8080/live/deric/deric/2257.ts'
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]Penthouse 1 HD Adult[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;url='
    li = xbmcgui.ListItem('[COLOR green]#####[/COLOR]XXXXXXXX[COLOR red]#####[/COLOR]', iconImage='XXXXX')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

	

    xbmcplugin.endOfDirectory(addon_handle)										
	
