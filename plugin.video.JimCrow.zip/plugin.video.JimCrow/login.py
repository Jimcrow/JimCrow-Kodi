#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import time
import urllib
import urllib2
import urlparse
#import Main

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon


def LoginWindow():
    window = Login('KongKidz')
    window.doModal()
    del window